@net.minecraftforge.fml.common.API(apiVersion = "1.0.0", owner = "EdwinMindcraft", provides = "SeasonAPI")
package mod.mindcraft.seasons.api;